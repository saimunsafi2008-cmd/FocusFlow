# FocusFlow (Android) — starter project

A native Kotlin + Jetpack Compose foundation for the FocusFlow digital-wellbeing app.

## Included in this first source drop
- Dark Compose dashboard with English/Bangla UI toggle.
- Usage-access permission entry point.
- Accessibility-service scaffold for detecting launches of user-selected blocked packages.
- Persistent local settings for selected package names and Strict Mode state.
- Strict Mode domain logic for **2 global emergency accesses per timer cycle**, each lasting **2 minutes**.
- Modular package boundaries (`data`, `domain`, `monitor`, `ui`) to support future feature modules.

## Important status / limitations
This is **starter source code, not a completed production app and not an APK**. The environment used to prepare this source did not have the Android SDK or Gradle installed, so it could not be compiled or device-tested here.

The current UI is an initial foundation. Full package-picker, real usage-stat aggregation, timer-cycle coordinator, scheduled reset, website filtering, focus schedules, reporting, backup/restore, Room schema/migrations, and hardened enforcement still need implementation and testing.

Android Accessibility-based blocking is best-effort, requires the user to explicitly enable the service, and can be disabled or bypassed by a device owner through system settings or uninstalling the app. FocusFlow cannot make itself uninstall-proof on a normal personal Android device. Do not use this app as a safety-critical control.

## Build
1. Install Android Studio (current stable) with Android SDK Platform 35 and JDK 17.
2. Open this folder as an existing Gradle project.
3. Let Gradle sync, then build the `app` debug variant.
4. Install the resulting debug APK on a test device.
5. In Android Settings, grant Usage Access and enable FocusFlow under Accessibility before testing blocking.

## Next engineering milestones
1. Query `UsageStatsManager` and render real daily/weekly statistics.
2. Add package discovery/selection and per-app timer configuration.
3. Implement a persisted timer-cycle coordinator and global emergency-session state machine.
4. Add an app-specific block screen, notification controls, and reboot/time-change recovery.
5. Add Room-backed records, migrations, backup/export, focus schedules, website blocking, and automated tests.
6. Validate behavior across Android versions and OEM battery-management settings.
