package com.focusflow.app

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focusflow.app.data.FocusStore
import com.focusflow.app.domain.StrictModeEngine

private val Bg = Color(0xFF0B1220)
private val Panel = Color(0xFF151F31)
private val Accent = Color(0xFF78B7FF)
private val Muted = Color(0xFF9AAAC0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = FocusStore(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Accent,
                onBackground = Color.White, onSurface = Color.White
            )) {
                FocusFlowHome(
                    store = store,
                    usageGranted = hasUsageAccess(),
                    onUsageSettings = { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) },
                    onAccessibilitySettings = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                )
            }
        }
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        return appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }
}

@Composable
private fun FocusFlowHome(
    store: FocusStore,
    usageGranted: Boolean,
    onUsageSettings: () -> Unit,
    onAccessibilitySettings: () -> Unit
) {
    var strict by remember { mutableStateOf(store.strictEnabled()) }
    var language by remember { mutableStateOf("English") }
    var showTimer by remember { mutableStateOf(false) }
    var minutes by remember { mutableIntStateOf(30) }
    var remaining by remember { mutableIntStateOf(store.loadStrictState().remainingAccesses) }

    val bn = language == "বাংলা"
    Column(
        Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("FocusFlow", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(if (bn) "সময়কে নিয়ন্ত্রণ করুন" else "Take control of your time", color = Muted)
            }
            TextButton(onClick = { language = if (bn) "English" else "বাংলা" }) { Text(if (bn) "EN" else "বাংলা") }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (bn) "আজকের স্ক্রিন টাইম" else "TODAY'S SCREEN TIME", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("-- h -- m", fontSize = 36.sp, fontWeight = FontWeight.Bold)
                Text(if (usageGranted) (if (bn) "ব্যবহারের তথ্যের অনুমতি দেওয়া হয়েছে" else "Usage access granted") else (if (bn) "স্ক্রিন টাইম দেখতে অনুমতি দিন" else "Grant usage access to read screen time"), color = Muted)
                if (!usageGranted) Button(onClick = onUsageSettings) { Text(if (bn) "অনুমতি দিন" else "Grant permission") }
            }
        }

        SectionTitle(if (bn) "ফোকাস টুলস" else "FOCUS TOOLS")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("30 min", if (bn) "দৈনিক লক্ষ্য" else "Daily goal", Modifier.weight(1f))
            MetricCard("$remaining / 2", if (bn) "জরুরি অ্যাক্সেস" else "Emergency passes", Modifier.weight(1f))
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (bn) "Strict Mode" else "Strict Mode", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(if (bn) "অ্যাপ সীমা শেষ হলে ব্লক করুন" else "Block selected apps after their limits", color = Muted, fontSize = 12.sp)
                    }
                    Switch(checked = strict, onCheckedChange = { strict = it; store.setStrictEnabled(it) })
                }
                Text(if (bn) "২টি বিশ্বব্যাপী জরুরি সেশন · প্রতিটি ২ মিনিট" else "2 global emergency passes · 2 minutes each", color = Accent, fontSize = 13.sp)
                OutlinedButton(onClick = onAccessibilitySettings, modifier = Modifier.fillMaxWidth()) {
                    Text(if (bn) "Accessibility সেটিংস" else "Configure blocking permission")
                }
            }
        }

        SectionTitle(if (bn) "আপনার টুলস" else "YOUR TOOLS")
        FeatureRow("⏱", if (bn) "অ্যাপ টাইমার" else "App timers", if (bn) "দৈনিক সীমা সেট করুন" else "Set daily limits") { showTimer = true }
        FeatureRow("🎯", if (bn) "ফোকাস সেশন" else "Focus sessions", if (bn) "বিক্ষেপ ছাড়া পড়াশোনা" else "Study without distractions") { }
        FeatureRow("📊", if (bn) "রিপোর্ট" else "Reports", if (bn) "সাপ্তাহিক অগ্রগতি" else "Weekly progress") { }
        FeatureRow("🧪", "FocusFlow Labs", if (bn) "পরীক্ষামূলক ফিচার" else "Experimental features") { }

        Text(if (bn) "আপনার ডেটা এই ডিভাইসেই থাকে।" else "Your data stays on this device by default.", color = Muted, fontSize = 11.sp)
    }

    if (showTimer) AlertDialog(
        onDismissRequest = { showTimer = false },
        containerColor = Panel,
        title = { Text(if (bn) "অ্যাপ টাইমার" else "App timer") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (bn) "দৈনিক সীমা: $minutes মিনিট" else "Daily limit: $minutes minutes")
                Slider(value = minutes.toFloat(), onValueChange = { minutes = it.toInt() }, valueRange = 5f..180f, steps = 34)
                Text(if (bn) "এটি প্রাথমিক UI। নির্বাচিত অ্যাপ ও সময়সূচি পরবর্তী ধাপে যুক্ত হবে।" else "This is the first UI slice. App selection and timer scheduling are next implementation steps.", color = Muted, fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton(onClick = { showTimer = false }) { Text(if (bn) "ঠিক আছে" else "Done") } }
    )
}

@Composable private fun SectionTitle(text: String) { Text(text, color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
@Composable private fun MetricCard(value: String, label: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) { Text(value, fontSize = 23.sp, fontWeight = FontWeight.Bold); Text(label, color = Muted, fontSize = 12.sp) }
    }
}
@Composable private fun FeatureRow(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(icon, fontSize = 22.sp)
            Column { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 12.sp) }
        }
    }
}
