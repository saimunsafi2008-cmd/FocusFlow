package com.focusflow.app

import android.app.Activity
import android.os.Bundle
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color

class BlockedActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = TextView(this).apply {
            text = "FocusFlow\n\nThis app is paused.\nএই অ্যাপটি আপাতত বন্ধ রাখা হয়েছে।"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(13, 20, 34))
            setPadding(32, 32, 32, 32)
        }
        setContentView(text)
    }
}

