package com.focusflow.app.domain

/**
 * Global emergency allowance for one configured timer cycle.
 * Two total passes are shared by every restricted app; each pass lasts two minutes.
 * The host app persists these values in SharedPreferences (see FocusStore).
 */
data class StrictState(
    val cycleId: Long,
    val remainingAccesses: Int = 2,
    val activeUntilMillis: Long? = null,
    val consumedForCycle: Boolean = false
)

class StrictModeEngine(private val accessCount: Int = 2, private val accessDurationMillis: Long = 120_000L) {
    fun startEmergencyAccess(state: StrictState, now: Long): StrictState? {
        if (state.activeUntilMillis != null && now < state.activeUntilMillis) return state
        if (state.remainingAccesses <= 0) return null
        return state.copy(
            remainingAccesses = state.remainingAccesses - 1,
            activeUntilMillis = now + accessDurationMillis,
            consumedForCycle = true
        )
    }

    fun isEmergencyAccessActive(state: StrictState, now: Long): Boolean =
        state.activeUntilMillis?.let { now < it } ?: false

    /** Call only when the app-timer cycle coordinator confirms a new cycle. */
    fun onNewTimerCycle(previous: StrictState, newCycleId: Long): StrictState =
        if (newCycleId != previous.cycleId) StrictState(cycleId = newCycleId, remainingAccesses = accessCount)
        else previous
}
