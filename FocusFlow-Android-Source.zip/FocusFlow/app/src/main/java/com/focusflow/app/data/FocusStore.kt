package com.focusflow.app.data

import android.content.Context
import com.focusflow.app.domain.StrictState

/** Small persistent store for the first MVP. Room migration is planned as modules grow. */
class FocusStore(context: Context) {
    private val prefs = context.getSharedPreferences("focusflow_state", Context.MODE_PRIVATE)

    fun blockedPackages(): Set<String> = prefs.getStringSet("blocked_packages", emptySet())?.toSet() ?: emptySet()
    fun setBlockedPackages(packages: Set<String>) {
        prefs.edit().putStringSet("blocked_packages", packages.toSet()).apply()
    }
    fun strictEnabled(): Boolean = prefs.getBoolean("strict_enabled", false)
    fun setStrictEnabled(enabled: Boolean) { prefs.edit().putBoolean("strict_enabled", enabled).apply() }

    fun loadStrictState(): StrictState = StrictState(
        cycleId = prefs.getLong("cycle_id", 0L),
        remainingAccesses = prefs.getInt("remaining_accesses", 2),
        activeUntilMillis = prefs.getLong("active_until", 0L).takeIf { it > 0L },
        consumedForCycle = prefs.getBoolean("consumed", false)
    )

    fun saveStrictState(state: StrictState) {
        prefs.edit()
            .putLong("cycle_id", state.cycleId)
            .putInt("remaining_accesses", state.remainingAccesses)
            .putLong("active_until", state.activeUntilMillis ?: 0L)
            .putBoolean("consumed", state.consumedForCycle)
            .apply()
    }
}
