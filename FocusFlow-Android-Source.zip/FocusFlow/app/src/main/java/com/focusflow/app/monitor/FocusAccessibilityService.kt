package com.focusflow.app.monitor

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.focusflow.app.BlockedActivity
import com.focusflow.app.data.FocusStore
import com.focusflow.app.domain.StrictModeEngine

/** Optional enforcement layer. User must explicitly enable it in Android Accessibility settings. */
class FocusAccessibilityService : AccessibilityService() {
    private lateinit var store: FocusStore
    private val engine = StrictModeEngine()

    override fun onServiceConnected() {
        super.onServiceConnected()
        store = FocusStore(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val packageName = event.packageName?.toString() ?: return
        if (packageName == this.packageName || !::store.isInitialized) return
        if (packageName !in store.blockedPackages() || !store.strictEnabled()) return

        val state = store.loadStrictState()
        val now = System.currentTimeMillis()
        if (engine.isEmergencyAccessActive(state, now)) return

        val intent = Intent(this, BlockedActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(BlockedActivity.EXTRA_PACKAGE, packageName)
        }
        startActivity(intent)
    }

    override fun onInterrupt() = Unit
}
